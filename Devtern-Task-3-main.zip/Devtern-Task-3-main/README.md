# Devtern-Task-3
Developed a to-do list for managing tasks 
